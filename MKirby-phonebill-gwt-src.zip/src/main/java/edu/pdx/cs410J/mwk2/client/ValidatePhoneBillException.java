package edu.pdx.cs410J.mwk2.client;

/**
 *
 */
public class ValidatePhoneBillException extends RuntimeException {
    public ValidatePhoneBillException(String message) {
        super(message);
    }

    public ValidatePhoneBillException() {
    }
}